fetch("/node_modules/enigma.js/schemas/12.67.2.json").then(response => {
  return response.json()
}).then(data => {

  let qlik
  let currSession
  let currApp

  var config = {
    schema: data,
    host: "localhost",
    prefix: "",
    port: "4848",
    url: `ws://localhost:4848/app`,
    rejectUnauthorized: false
  };


  var session = enigma.create(config)
  session.open().then(global => {
    qlik = global
    loadDocList()
  })

  async function loadDocList() {
    let docs = await qlik.getDocList()
      let html = ''
      docs.forEach(d => {
        if (d.qTitle.indexOf('test') >= 0) {
          html += `
              <li>
                <h3 class="scriptSelect" data-value="${d.qDocName}">${d.qTitle}</h3>
                <p>Last reload: ${d.qLastReloadTime}</p>
              </li>`
        }
      })
      document.getElementById('appList').innerHTML = html
  }

  let appReload = document.getElementById('reload')
  if (appReload) {
    appReload.addEventListener('click', () => {
      if (currApp) {
        const script = document.getElementById('script').value;
        (async function () {
          await currApp.setScript(script)
          let result = await currApp.doReload()
          await currApp.doSave()
          if (result === true) {
            document.getElementById('progress').innerText = 'COMPLETE'
          }
        })()
    
      }
    })
  }
  
  let appSelect = document.getElementById('appList')
  if (appSelect) {
    appSelect.addEventListener('click', (e) => {
      e.preventDefault();
      let appId = e.target.attributes["data-value"].value
      console.log(appId)
      connect(appId)

    })
  }

  async function connect(appId) {
    if (currApp && currApp.close) {
      currApp.close()
      currApp = null
    }
    if (currSession && currSession.close) {
      currSession.close()
      currSession = null
    }
    const config = {
      url: `ws://localhost:4848/app/${appId}`,
      schema: data
    }
    currSession = enigma.create(config)
    let global = await currSession.open()
      // session.open().then(global => {
    let app = await  global.openDoc(appId)
        currApp = app
        getScript()
  }

  async function getScript() {
    let script = await currApp.getScript()
      console.log(script);
      document.getElementById("script").value = script
  }

  // class updateFilter {
  //   constructor(elementId, model) {
  //     this.model = model
  //     this.model.addListener('changed', () => this.getLayout())
  //     window.addEventListener("resize", () => this.render())
  //     // this.model.addListener('changed', ()=>this.selectValues(e))
  //     // this.selectValues = this.model.addListener('changed', e =>this.selectValues(e).bind(this))

  //     this.filtersEl = document.getElementById(elementId);
  //     // NICK
  //     this.filtersEl.innerHTML = `
  //       <h3>Minerva</h3>
  //       <div class="dropdown">				
  // 			  <button id="openFilter" class="dropbtn">Dropdown</button>
  //           <div id="select_${elementId}" class="dropdown-content">
  //           `;



  //     this.opencloseEl = document.getElementById("openFilter");
  //     if (this.opencloseEl) {
  //       this.opencloseEl.addEventListener('click', this.clickButton.bind(this))

  //       //this.selectEl.addEventListener('click', this.selectValues.bind(this))
  //     }

  //     this.selectEl = document.getElementById(`select_${elementId}`);
  //     if (this.selectEl) {
  //       this.selectEl.addEventListener('click', this.selectValues.bind(this))
  //     }

  //     this.getLayout()

  //   }
  //   getLayout() {
  //     this.model.getLayout().then(layout => {

  //       //console.log(layout)
  //       this.calculatePeriod = layout.filterMinerva.qListObject.qDataPages[0].qMatrix
  //       //this.calculatePeriod = layout.qHyperCube.qDataPages[0].qMatrix


  //       this.render()



  //     })
  //   }
  //   render() {
  //     // NICK (refactored a little)
  //     let filterHTML = '<input type="text" placeholder="Search.." id="myInput">'


  //     // `;<option value="-1">All</option>
  //     for (var i = 0; i < this.calculatePeriod.length; i++) {
  //       filterHTML += `
  //             <a class="${(this.calculatePeriod[i][0].qState=="S")?'selected':''}" data-elem-number="${this.calculatePeriod[i][0].qElemNumber}">
  //               ${this.calculatePeriod[i][0].qText}
  //             </a>
  //           `;
  //     }
  //     filterHTML += "</div></div>"
  //     this.selectEl.innerHTML = filterHTML;

  //     this.searchEl = document.getElementById("myInput");
  //     if (this.searchEl) {
  //       this.searchEl.addEventListener('keyup', this.filterFunction.bind(this))
  //     }
  //   }
  //   clickButton() {
  //     this.selectEl.classList.toggle("show")

  //   }
  //   selectValues(e) {

  //     //var elemNumber = +e.target.value
  //     var elemNumber = +e.target.attributes["data-elem-number"].value
  //     this.model.selectListObjectValues("/filterMinerva/qListObjectDef", [elemNumber], false)

  //   }
  //   filterFunction() {
  //     var filter, ul, li, a, i;
  //     filter = this.searchEl.value.toUpperCase();
  //     a = this.selectEl.getElementsByTagName("a");
  //     console.log(a.length)
  //     for (i = 0; i < a.length; i++) {
  //       if (a[i].innerHTML.toUpperCase().indexOf(filter) > -1) {
  //         a[i].style.display = "";
  //       } else {
  //         a[i].style.display = "none";
  //       }
  //     }
  //   }
  // }



})